# Archived
lost interest check out [Pork's version](https://github.com/PorkDevMode/AiSponge)

# sponge-ai
inspired by [ai sponge](https://www.youtube.com/watch?v=b4cJjkI5uGw).

# Requirements
[uberduck api key and secret](http://uberduck.ai)

[openai api key](https://platform.openai.com/account/api-keys)

[OpenAI-Unity](https://github.com/srcnalt/OpenAI-Unity/releases/tag/v0.1.13) by [srcnalt](https://github.com/srcnalt)

# Tutorial
https://www.youtube.com/watch?v=XrYNB16SNQQ

# How to use
create an empty game object and add the AIThing script to it.

insert the keys and stuff in the script's corresponding input boxes.

If you want the camera to follow the characters as they talk create a Cinemachine camera and call the characters gameobject's the same as they're called in the Generate method in AIThing.cs

for subtitles and video player to work create a canvas and add a textmeshpro and video player as children to the canvas. set the video player's render mode to Camera Near Plane and put the camera in the camera field.

# Preview




https://github.com/Interesting-exe/sponge-ai/assets/52731127/367a02e5-0012-4951-8217-698715116fcd

